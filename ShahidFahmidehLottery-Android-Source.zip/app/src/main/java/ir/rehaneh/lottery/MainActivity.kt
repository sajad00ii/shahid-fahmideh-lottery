package ir.rehaneh.lottery

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.animation.ValueAnimator
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.MediaPlayer
import android.text.InputType
import java.text.SimpleDateFormat
import java.util.*

data class Draw(val id: Long, val title: String, val date: String, val results: List<String>, val remaining: List<String>)

class Store(c: Context): SQLiteOpenHelper(c, "lottery.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE draws(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,date TEXT,results TEXT,remaining TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun save(title:String, results:List<String>, remaining:List<String>) {
        val cv=android.content.ContentValues()
        cv.put("title",title); cv.put("date",SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.getDefault()).format(Date()))
        cv.put("results",results.joinToString("\n")); cv.put("remaining",remaining.joinToString("\n"))
        writableDatabase.insert("draws",null,cv)
    }
    fun all():List<Draw> {
        val out= mutableListOf<Draw>()
        readableDatabase.rawQuery("SELECT * FROM draws ORDER BY id DESC",null).use { c ->
            while(c.moveToNext()) out.add(Draw(c.getLong(0),c.getString(1),c.getString(2),
                c.getString(3).split("\n").filter{it.isNotBlank()},c.getString(4).split("\n").filter{it.isNotBlank()}))
        }
        return out
    }
    fun delete(id:Long) { writableDatabase.delete("draws","id=?", arrayOf(id.toString())) }
}

class WheelView(c: Context): View(c) {
    var names: List<String> = emptyList()
    var rotation = 0f
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx=width/2f; val cy=height/2f; val r=minOf(width,height)*.43f
        if(names.isEmpty()) {
            p.color=Color.LTGRAY; canvas.drawCircle(cx,cy,r,p)
            p.color=Color.DKGRAY; p.textAlign=Paint.Align.CENTER; p.textSize=38f
            canvas.drawText("اسامی را وارد کنید",cx,cy,p); return
        }
        val colors=intArrayOf(Color.rgb(30,75,83),Color.rgb(205,151,70),Color.rgb(57,105,91),Color.rgb(120,76,72),Color.rgb(55,85,115))
        canvas.save(); canvas.rotate(rotation,cx,cy)
        val sweep=360f/names.size
        names.forEachIndexed { i,n ->
            p.color=colors[i%colors.size]; canvas.drawArc(cx-r,cy-r,cx+r,cy+r,i*sweep,sweep,true,p)
            p.color=Color.WHITE; p.textSize=(if(names.size>12) 17f else 23f); p.textAlign=Paint.Align.CENTER
            val a=Math.toRadians((i*sweep+sweep/2-90).toDouble())
            val tx=cx+cos(a).toFloat()*r*.62f; val ty=cy+sin(a).toFloat()*r*.62f
            canvas.save(); canvas.rotate(i*sweep+sweep/2,cx,cy); canvas.drawText(n.take(13),tx,ty,p); canvas.restore()
        }
        p.color=Color.WHITE; canvas.drawCircle(cx,cy,r*.13f,p)
        p.color=Color.rgb(23,43,53); canvas.drawCircle(cx,cy,r*.09f,p)
        canvas.restore()
        p.color=Color.rgb(23,43,53)
        val path=Path().apply { moveTo(cx,cy-r-12); lineTo(cx-24,cy-r-52); lineTo(cx+24,cy-r-52); close() }
        canvas.drawPath(path,p)
    }
    private fun cos(v:Double)=kotlin.math.cos(v)
    private fun sin(v:Double)=kotlin.math.sin(v)
}

class MainActivity : Activity() {
    private lateinit var store:Store
    private lateinit var wheel:WheelView
    private lateinit var namesBox:EditText
    private lateinit var titleBox:EditText
    private lateinit var resultsBox:TextView
    private lateinit var status:TextView
    private var names= mutableListOf<String>()
    private var results= mutableListOf<String>()
    private var currentTitle="قرعه‌کشی جدید"
    private var music:MediaPlayer?=null
    private var spinning=false
    private val bg=Color.rgb(245,242,235)
    private val ink=Color.rgb(23,43,53)
    private val gold=Color.rgb(190,132,53)

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        store=Store(this)
        buildUi()
    }
    private fun buildUi() {
        val root=LinearLayout(this).apply { orientation=1; setPadding(22,18,22,20); setBackgroundColor(bg) }
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER_HORIZONTAL }
        val header=TextView(this).apply {
            text="قرعه‌کشی شهید فهمیده\nکانون فرهنگی ریحانةالرسول (س)"
            textSize=21f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(12,20,12,20)
            setBackgroundColor(ink)
        }
        content.addView(header, LinearLayout.LayoutParams(-1,-2))
        titleBox=EditText(this).apply { hint="عنوان قرعه‌کشی؛ مثلاً مسابقه هفتگی"; textSize=16f }
        content.addView(titleBox)
        val namesLabel=label("اسامی شرکت‌کنندگان (هر اسم در یک خط)")
        content.addView(namesLabel)
        namesBox=EditText(this).apply {
            minLines=4; gravity=Gravity.TOP; textSize=16f; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            hint="علی\nمحمد\nزهرا"
        }
        content.addView(namesBox,LinearLayout.LayoutParams(-1,150))
        content.addView(button("ثبت / به‌روزرسانی اسامی",gold){ loadNames() })
        wheel=WheelView(this)
        content.addView(wheel,LinearLayout.LayoutParams(-1,300))
        content.addView(button("🎵 موسیقی ملایم: روشن / خاموش",ink){ toggleMusic() })
        content.addView(button("چرخاندن گردونه و انتخاب برنده",gold){ spin() })
        status=label("آماده قرعه‌کشی")
        content.addView(status)
        content.addView(label("نتایج به ترتیب قرعه‌کشی"))
        resultsBox=TextView(this).apply { textSize=17f; setTextColor(ink); setPadding(12,12,12,12); setBackgroundColor(Color.WHITE); text="هنوز برنده‌ای انتخاب نشده است" }
        content.addView(resultsBox,LinearLayout.LayoutParams(-1,-2))
        content.addView(button("ذخیره و پایان قرعه‌کشی",ink){ finishDraw() })
        content.addView(button("خروجی PDF نتایج",gold){ exportPdf() })
        content.addView(button("ارسال نتایج با پیامک به 09163762086",ink){ sendSms() })
        content.addView(button("قرعه‌کشی جدید",gold){ newDraw() })
        content.addView(button("آرشیو قرعه‌کشی‌های قبلی",ink){ showArchive() })
        content.addView(button("کانال ایتای کانون ریحانةالرسول (س)",gold){
            startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://eitaa.com/kanoon_farhangi")))
        })
        content.addView(label("مجموعه کانون فرهنگی ریحانةالرسول (س) | دوره شهید فهمیده"))
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }
    private fun label(s:String)=TextView(this).apply { text=s; textSize=15f; setTextColor(ink); setPadding(4,12,4,8) }
    private fun button(s:String,color:Int, action:()->Unit)=Button(this).apply {
        text=s; textSize=14f; setTextColor(Color.WHITE); setBackgroundColor(color)
        setOnClickListener { action() }
        layoutParams=LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,6,0,6) }
    }
    private fun loadNames() {
        val parsed=namesBox.text.toString().lines().map{it.trim()}.filter{it.isNotEmpty()}.distinct()
        if(parsed.size<2) { toast("حداقل دو اسم متفاوت وارد کن."); return }
        names=parsed.toMutableList(); results.clear(); currentTitle=titleBox.text.toString().trim().ifEmpty{"قرعه‌کشی جدید"}
        wheel.names=names.toList(); wheel.rotation=0f; wheel.invalidate(); updateResults()
        status.text="${names.size} نفر آماده قرعه‌کشی هستند."
    }
    private fun spin() {
        if(spinning) return
        if(names.isEmpty()) { toast("ابتدا اسامی را ثبت کن."); return }
        spinning=true
        val chosen=Random().nextInt(names.size)
        val segment=360f/names.size
        val target=wheel.rotation+360f*(4+Random().nextInt(3))+(360f-(chosen*segment+segment/2))
        ValueAnimator.ofFloat(wheel.rotation,target).apply {
            duration=4200; interpolator=DecelerateInterpolator()
            addUpdateListener { wheel.rotation=it.animatedValue as Float; wheel.invalidate() }
            start()
        }.addListener(object: android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation:android.animation.Animator) {
                val winner=names.removeAt(chosen); results.add(winner)
                wheel.names=names.toList(); wheel.invalidate(); updateResults()
                status.text="برنده شماره ${results.size}: $winner"
                spinning=false
                if(names.isEmpty()) status.text="قرعه‌کشی تمام شد!"
            }
        })
    }
    private fun updateResults() {
        resultsBox.text=if(results.isEmpty()) "هنوز برنده‌ای انتخاب نشده است"
        else results.mapIndexed{i,n -> "${i+1}. $n"}.joinToString("\n")
    }
    private fun finishDraw() {
        if(results.isEmpty()) { toast("هنوز نتیجه‌ای ثبت نشده است."); return }
        store.save(currentTitle,results,names)
        toast("قرعه‌کشی در آرشیو ذخیره شد.")
    }
    private fun newDraw() {
        names.clear(); results.clear(); namesBox.setText(""); titleBox.setText("")
        wheel.names=emptyList(); wheel.rotation=0f; wheel.invalidate(); updateResults()
        status.text="قرعه‌کشی جدید آماده است."; currentTitle="قرعه‌کشی جدید"
    }
    private fun showArchive() {
        val items=store.all()
        if(items.isEmpty()) { toast("هنوز قرعه‌کشی آرشیوشده‌ای وجود ندارد."); return }
        val labels=items.map{"${it.title}  |  ${it.date}  |  ${it.results.size} برنده"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("آرشیو قرعه‌کشی‌ها").setItems(labels){_,which->
            val d=items[which]
            AlertDialog.Builder(this).setTitle(d.title).setMessage(
                "تاریخ: ${d.date}\n\n"+d.results.mapIndexed{i,n->"${i+1}. $n"}.joinToString("\n")
            ).setPositiveButton("حذف از آرشیو"){_,_->store.delete(d.id);toast("حذف شد.")}.setNegativeButton("بستن",null).show()
        }.setNegativeButton("بستن",null).show()
    }
    private fun exportPdf() {
        if(results.isEmpty()) { toast("نتیجه‌ای برای خروجی گرفتن وجود ندارد."); return }
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/pdf"
            putExtra(Intent.EXTRA_TITLE,"نتایج-${currentTitle}.pdf")
        }
        startActivityForResult(intent,101)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==101 && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            try {
                val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
                val p=Paint().apply { color=ink; textSize=20f; textAlign=Paint.Align.RIGHT }
                page.canvas.drawText("قرعه‌کشی شهید فهمیده",550f,60f,p)
                p.textSize=16f; page.canvas.drawText(currentTitle,550f,100f,p)
                results.forEachIndexed{i,n->page.canvas.drawText("${i+1}. $n",550f,150f+i*32,p)}
                doc.finishPage(page)
                contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}
                doc.close(); toast("فایل PDF ذخیره شد.")
            } catch(e:Exception){ toast("ساخت PDF ناموفق بود.") }
        }
    }
    private fun sendSms() {
        if(results.isEmpty()) { toast("نتیجه‌ای برای ارسال وجود ندارد."); return }
        val body="نتایج ${currentTitle} - قرعه‌کشی شهید فهمیده:\n"+results.mapIndexed{i,n->"${i+1}. $n"}.joinToString("\n")
        val intent=Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:09163762086")).putExtra("sms_body",body)
        try { startActivity(intent) } catch(e:Exception) { toast("برنامه پیامک در دسترس نیست.") }
    }
    private fun toggleMusic() {
        try {
            if(music?.isPlaying==true) { music?.pause(); toast("موسیقی متوقف شد.") }
            else {
                if(music==null) music=MediaPlayer.create(this,R.raw.soft_music)
                music?.isLooping=true; music?.start(); toast("موسیقی ملایم پخش می‌شود.")
            }
        } catch(e:Exception) { toast("پخش موسیقی در این دستگاه ممکن نیست.") }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onDestroy() { music?.release(); music=null; super.onDestroy() }
}
